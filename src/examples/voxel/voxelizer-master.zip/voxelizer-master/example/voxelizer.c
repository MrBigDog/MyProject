#define VOXELIZER_IMPLEMENTATION
#include "../voxelizer.h"

#if 1
int main() {
    return 0;
}
#endif